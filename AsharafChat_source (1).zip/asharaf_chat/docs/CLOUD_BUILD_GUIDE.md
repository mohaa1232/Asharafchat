# Building AsharafChat from Your Android Phone — No Computer Needed

**Recommended combo:** GitHub (to host the code) + GitHub Codespaces (to unzip/
configure it, all in a browser) + **Codemagic** (to actually compile and sign
the APK). Codemagic is the recommendation if you were only going to use one
service, because it comes with Flutter + Android SDK + Gradle preinstalled and
does code signing through a web form — no terminal commands needed for the
build itself, which matters a lot when you're typing on a phone.

Gitpod and Replit can technically run Linux VMs too, but neither has
Codemagic's purpose-built, no-terminal Android signing UI — you'd be doing
the whole Android SDK install and Gradle build by hand in a phone browser
terminal, which is slow and easy to get stuck on. Skip them for this.

---

## Step 1 — Get the project onto GitHub

1. On your phone browser, go to **github.com** → sign up / log in.
2. Tap **+ → New repository**. Name it `asharafchat`, set it **Private**,
   check "Add a README", then **Create repository**.
3. On the repo page: **Code → Codespaces tab → Create codespace on main**.
   This opens a full VS Code environment in your browser (give it a minute
   to spin up).
4. In the Codespace's file explorer (left sidebar), tap the **⋯** menu →
   **Upload...** → pick the `AsharafChat_source.zip` file from your phone's
   downloads (download it from this chat first if you haven't).
5. Open the built-in **Terminal** (menu → Terminal → New Terminal) and run:
   ```bash
   unzip AsharafChat_source.zip -d .
   mv asharaf_chat/* asharaf_chat/.[!.]* . 2>/dev/null; rmdir asharaf_chat
   rm AsharafChat_source.zip
   git add -A
   git commit -m "Initial AsharafChat commit"
   git push
   ```
   (The `mv` line moves everything out of the extracted subfolder so
   `pubspec.yaml` sits at your repo root — Codemagic expects that.)

Your code is now on GitHub and viewable/editable from any browser.

---

## Step 2 — Configure Firebase (no CLI needed — do this via the console)

1. Go to **console.firebase.google.com** → **Add project** → name it
   `asharafchat-prod`.
2. **Add app → Android**. Package name: `com.jiyaad.asharafchat` (must match
   what's in `android/app/build.gradle` in your repo — open that file in
   the Codespace to confirm/edit it if you want a different name).
3. Download **`google-services.json`** when prompted.
4. Back in your Codespace: upload `google-services.json` the same way you
   uploaded the zip (Explorer → ⋯ → Upload...), placing it at
   `android/app/google-services.json`.
5. In Firebase Console, go to **Project settings → General**, scroll to
   "Your apps," and note these values for your Android app: **API key**,
   **App ID**, **Project ID**, **Storage bucket**, **Messaging sender ID**.
6. In the Codespace, create `lib/firebase_options.dart` with this content,
   filling in the values from step 5:
   ```dart
   import 'package:firebase_core/firebase_core.dart';

   class DefaultFirebaseOptions {
     static FirebaseOptions get currentPlatform => android;

     static const FirebaseOptions android = FirebaseOptions(
       apiKey: 'PASTE_API_KEY',
       appId: 'PASTE_APP_ID',
       messagingSenderId: 'PASTE_SENDER_ID',
       projectId: 'PASTE_PROJECT_ID',
       storageBucket: 'PASTE_STORAGE_BUCKET',
     );
   }
   ```
7. In the Firebase Console, enable: **Authentication** (Phone, Email/Password,
   Google sign-in methods), **Firestore Database** (production mode),
   **Storage**. Cloud Messaging and Crashlytics activate automatically once
   the app runs — nothing to toggle manually there.
8. Deploy the security rules from your repo without installing anything
   locally: in Firebase Console, go to **Firestore → Rules**, paste the
   contents of `firebase/firestore.rules` (open it in the Codespace to copy
   it) and **Publish**. Do the same for **Storage → Rules** with
   `firebase/storage.rules`.
9. Cloud Functions (`functions/index.js`) do require the CLI, which needs
   the Blaze (pay-as-you-go) plan. You can skip deploying these initially —
   the app works for chat without them; you'll just be missing push
   notifications until you deploy them later. If you want them now, this is
   the one place a Codespace terminal session is genuinely useful:
   ```bash
   npm install -g firebase-tools
   firebase login --no-localhost   # follow the printed URL, paste the code back
   cd functions && npm install && cd ..
   firebase deploy --only functions --project asharafchat-prod
   ```
10. Commit and push these changes from the Codespace terminal:
    ```bash
    git add -A
    git commit -m "Add Firebase config"
    git push
    ```

---

## Step 3 — `flutter pub get`

You don't need to run this yourself — Codemagic runs it automatically as
part of every build. (If you want to sanity-check the project in Codespaces
first, you can install Flutter there and run it manually, but it's optional.)

---

## Step 4 — Connect Codemagic and configure the build

1. Go to **codemagic.io** on your phone → **Sign up** using your GitHub
   account (this grants Codemagic read access to your repos).
2. **Add application** → select your `asharafchat` repo. Codemagic
   auto-detects it's a Flutter project.
3. In the app's **Workflow editor**, under **Build**, select platform
   **Android**, build format **APK**, mode **Release**.

## Step 5 — Set up signing and build the signed release APK

1. Still in the Workflow editor, go to **Code signing → Android code
   signing**.
2. You have two options:
   - **Let Codemagic generate a keystore for you** (simplest): use their
     "generate a new keystore" option. **Immediately download and save the
     generated keystore file and its passwords somewhere safe** (e.g. your
     own Google Drive) — you'll need the exact same keystore for every
     future update, or existing users can't install the new version over
     the old one.
   - **Upload your own keystore**, if you already generated one elsewhere.
3. Save the workflow, then tap **Start new build**. A Flutter Android
   release build typically takes a few minutes; you're within Codemagic's
   500 free minutes/month for occasional builds like this.
4. When it finishes, open the build → **Artifacts** tab → you'll see
   `app-release.apk` listed with a download link.

---

## Step 6 — Get the APK onto your Android phone

Since you're already doing all of this from your phone's browser:

1. Tap the `.apk` link in Codemagic's Artifacts tab.
2. Your phone will download it straight to your **Downloads** folder — no
   extra transfer step needed, since you never left the phone.

---

## Step 7 — Share the APK with your friends (no Google Play needed)

Send the downloaded `app-release.apk` file directly via:

- **WhatsApp / Telegram**: attach it like any file in a chat or group.
- **Email**: attach it (some providers block `.apk` attachments — if so,
  rename it to `app-release.zip` before sending and have the recipient
  rename it back, or use one of the options below instead).
- **Bluetooth / Nearby Share**: fine for handing it to people in person.
- **A direct download link**: upload the APK to Google Drive, set sharing
  to "anyone with the link," and send that single link — most reliable for
  reaching many people since it's not re-compressed by a chat app.

Tell each friend, when they open the file:

1. Android will warn: *"For your security, your phone is not allowed to
   install unknown apps from this source."* → tap **Settings**.
2. Toggle **"Allow from this source"** on (this is the per-app "Install
   unknown apps" permission, granted once for whichever app they used to
   open the file — WhatsApp, Files, Chrome, etc.).
3. Go back and tap the APK again → **Install**.
4. Open AsharafChat, sign up with phone number or email, and start
   chatting with anyone else who's installed it — they're all on the same
   Firebase backend you configured above.

## Updating the app later

Push new commits to GitHub → tap **Start new build** in Codemagic again
(same signing config, same keystore) → share the new APK the same way.
Users just install over the old one; their chat history lives in Firestore,
not on the device, so nothing is lost.
